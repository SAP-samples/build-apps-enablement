var response = '{"status": "204"}';
context.setVariable("response.status.code", "200");
context.setVariable("response.content", response);
