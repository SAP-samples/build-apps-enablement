function setOAuthConfig()
{
 context.setVariable("boc.basic", "Place it here the value of ->" + "Basic " + atob("<ClitentID>:<Secret>"));
 context.setVariable("boc.contentype","application/json");
 


}
setOAuthConfig();
